 
var REQUEST_STATUS_PENDING  =  "Pending"
var REQUEST_STATUS_REJECTED_BY_DONOR  =  "Rejected By Donor"
var REQUEST_STATUS_CANCELLED_BY_RECEIVER =  "Cancelled By Receiver"
var PENDING_FROM_ADMIN  =  "Pending Admin Approval"
var APPROVED_BY_ADMIN  =  "Approved By Admin"
var Cancelled_BY_ADMIN  =  "Cancelled By Admin"
